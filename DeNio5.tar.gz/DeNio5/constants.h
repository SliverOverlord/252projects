// File:    constants.h
// Author:  Joshua DeNio
// Program: 5
// Date:   2/27/2018 

// Description: This file contains constant declarations for program 5.

// set constants.
const int arraySize = 30;
const int sentinal = -1;

const float AMin = 90;
const float BMin = 80;
const float CMin = 70;
const float DMin = 60;
