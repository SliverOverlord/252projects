// File:    constants.h
// Author:  Joshua DeNio
// Program: 6
// Date:   3/19/2018 

// Description: This file contains constant declarations for program 6.

// set constants.
const int arraySize = 30;


// set grade constants.
const float AMin = 90;
const float BMin = 80;
const float CMin = 70;
const float DMin = 60;
